
import re
from pathlib import Path

CREMAD_LABELS = {
    # Mapping of emotion code in filename to readable label
    # Filename pattern: <ID>_<Actor>_<Emotion>_<Intensity>.wav
    # Example: 1001_DFA_ANG_XX.wav
    "ANG": "Anger",
    "DIS": "Disgust",
    "FEA": "Fear",
    "HAP": "Happy",
    "NEU": "Neutral",
    "SAD": "Sad",
}

def parse_cremad_filename(fname: str):
    """Parse a CREMA-D filename to extract (actor_id, emotion_code).

    Expected pattern: <ID>_<Actor>_<Emotion>_<Intensity>.wav
    Example: 1001_DFA_ANG_XX.wav -> ('1001', 'ANG')
    """
    name = Path(fname).name
    m = re.match(r"(\d{4})_[A-Z]{3}_(\w{3})_.+\.wav$", name)
    if not m:
        return None, None
    actor_id, emo = m.group(1), m.group(2)
    return actor_id, emo
